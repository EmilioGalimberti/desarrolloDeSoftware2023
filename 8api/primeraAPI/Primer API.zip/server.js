import http from 'http'
import servicio from './service/usuariosService.js'

http.createServer(async function (req, res){
    res.writeHead(200, {'Content-Type': 'text/html'}); // http header
    var url = req.url
if(url === '/hola' && req.method === 'GET'){
    res.write("Bienvenidos a nuestra api")
    res.end()
}else if(url === '/usuarios' && req.method === 'GET'){
    const result = await servicio.obtener_usuarios()
    res.write(JSON.stringify(result))
    res.end()
}else if(url === '/nuevoUsuario' && req.method === 'POST'){
    let body = ''
    req.on('data', buffer => {
        body+= buffer.toString()
    })
    req.on('end', () => {
        const bodyObject = JSON.parse(body)
        console.log(body)
        res.write(JSON.stringify(bodyObject))
        res.end()
    })
}
}).listen(3000, function(){
    console.log("Api escuchando en puerto 3000")
})