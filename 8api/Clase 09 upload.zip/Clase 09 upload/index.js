import * as service from "./service/usuarioService.js"
import {sequelize} from  "./data/db.js"

(async function(){
    try{
        let r = null;
        await sequelize.sync().then(()=>{
            console.log("DB Clase07.db sincronizada");
        })
        // console.log("****** TODOS LOS USUARIOS")
        // r = await service.obtenerUsuarios();
        // console.log(r);
        // console.log("****** USUARIO CON ID 2")
        // r = await service.obtenerPorId(2);
        //console.log(r);
    }
    catch (err){
        console.log(err);
    }
})()