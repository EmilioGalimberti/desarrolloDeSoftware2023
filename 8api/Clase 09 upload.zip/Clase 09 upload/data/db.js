import {Sequelize} from 'sequelize'

export const sequelize = new Sequelize("Clase07","","",{
    dialect: "sqlite",
    storage: "./data/Clase07.db"
})