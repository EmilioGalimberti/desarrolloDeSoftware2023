import { Console } from 'console';
import http from 'http'
import {obtenerUsuarios} from './service/usuarioService.js'

//Crear un servidor api
http.createServer(async function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});

    let url = req.url;
    if(url === '/Hola' && req.method === 'GET'){
        res.write("bienvenidos al curso de dds"); //escribiendo una respuesta
        res.end();
    }
    else if(url === '/GetUsuarios' && req.method === 'GET'){
        const result = await obtenerUsuarios();
        res.write(JSON.stringify(result));
        res.end();
    }
    else if(url === '/nuevoUsuario' && req.method === 'POST'){
        let body = '';
        req.on('data', buffer => {
            body += buffer.toString();
        })

        req.on('end', () =>{
            const bodyObject = JSON.parse(body);
            console.log(body);
            res.end("Ok");
        })
    } 
}).listen(3000, function(){
    console.log("Api corriendo en puerto 3000");
})