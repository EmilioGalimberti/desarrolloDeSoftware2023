import fetch from "node-fetch"
import {Usuario} from "../models/Usuario.js"
import {Sequelize} from "sequelize"

export async function obtenerUsuarios(){
    return await Usuario.findAll();
}

export async function obtenerPorId(idUsuario){
   return await Usuario.findAll({
        where: {
        id: idUsuario
    }})
}

// export async function obtenerPorPatron(patron){
//     const Op = Sequelize.Op;
//     return await Usuario.findAll({
//         where: {
//             name: { [Op.like]: }
//         }
//     })
//}