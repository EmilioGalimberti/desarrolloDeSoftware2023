export class Post{
    id;
    slug;
    url;

    constructor(){
        this.id = 0
        this.slug = ''
        this.url = ''
    }
}