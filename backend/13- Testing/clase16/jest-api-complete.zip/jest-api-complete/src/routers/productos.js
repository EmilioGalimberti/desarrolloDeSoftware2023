const express = require("express");
const Producto = require('../models/productos.js')

const router = express.Router()
router.get('/productos', async (req, res) => {
    const productos = await Producto.findAll()
    res.json(productos)
})

router.get('/productos/:id', async (req, res) => {
    try {
        const id = req.params.id
        const found = await Producto.findOne({ where: { id: id } })
        if (found) {
            res.json(found)
        } else {
            res.status(404).send({ mensaje: 'Producto inexistente!' })
        }
        console.log(found)
    } catch (error) {
        res.status(500).send({ mensaje: 'Error interno!' })
    }
})

router.post('/productos', async (req, res) => {
    try {
        const data = req.body
        console.log(data)
        const producto = await Producto.create(data)
        res.json(producto)

    } catch (error) {
        res.status(500).send({ mensaje: 'Error interno!' })
    }
})


module.exports = { router }