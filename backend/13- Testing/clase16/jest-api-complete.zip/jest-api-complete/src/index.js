const express = require('express')

const productos = require('./routers/productos.js')

const app = express()
app.use(express.json())
const PORT = 3000
app.use('/api', productos.router)

app.listen(PORT, async() => {
    console.log(`App listening on port ${PORT}`)  
})