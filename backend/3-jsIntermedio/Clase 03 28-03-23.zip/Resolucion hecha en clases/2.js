class Persona{
    constructor(nombre, apellido, correo){
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
    }

    saludar(){
        console.log("Hola amigo");
    }
}

function iniciar(){
    let p = new Persona('Nico', 'Horenstein', 'nicolashorenstein@gmail.com');
    console.log(p);
}

let p = new Persona('Nico', 'Horenstein', 'nicolashorenstein@gmail.com');
    console.log(p);