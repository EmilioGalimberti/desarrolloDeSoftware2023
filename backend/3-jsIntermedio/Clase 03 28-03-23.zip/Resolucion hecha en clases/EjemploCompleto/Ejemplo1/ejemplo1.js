const promedio = (acu, cantidad) =>{
    let prom = 0;
    if(cantidad >0){
        prom = acu / cantidad
    }
    return prom;
}

const mes_anio = mes =>{
    const meses = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];
    return meses[mes];
}

function leerPrecipitaciones(){
    lecturas = [];

    for(let i = 0; i< 12; i++){
        let lectura = {
            mes: i+1,
            valor: 15 + Math.floor(Math.random() * 20 )// valores comprendidos en el intervalo 15 a 35
        }
        lecturas.push(lectura);
    }

    return lecturas;
}

(function(){
    console.clear();

    let min;
    let acu_anual = 0;
    let acu_semestre = 0;

    const lecturas = leerPrecipitaciones();
    console.log(lecturas);

    lecturas.forEach(lectura => {
        if(lectura.mes ===1){
            min = lecturas[0];
        } else{
            if(lectura.mes > 5 && lectura.mes <= 12){
                acu_semestre += lectura.valor;
            }

            //determinar lectura minima
            if(lectura.valor < min.valor){
                min = lectura;
            }
        }
        acu_anual += lectura.valor
    });

    //Resultados:
    let prom_anual = promedio(acu_anual,12);
    console.log("Promedio anual: " + prom_anual);

    let prom_semestral = promedio(acu_semestre, 6);
    console.log("Promedio semestre: " + prom_semestral);


})();