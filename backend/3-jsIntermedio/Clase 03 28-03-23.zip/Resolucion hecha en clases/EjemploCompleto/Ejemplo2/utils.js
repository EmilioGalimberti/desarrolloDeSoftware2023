const promedio = (acu, cantidad) =>{
    let prom = 0;
    if(cantidad >0){
        prom = acu / cantidad
    }
    return prom;
}

const mes_anio = mes =>{
    const meses = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];
    return meses[mes];
}

export default{
    promedio,
    mes_anio
}