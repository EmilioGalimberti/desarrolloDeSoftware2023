import utils from './utils.js';
import lecturas from './datos.json' assert {type: 'json'}

(function(){
    let min;
    let acu_anual = 0;
    let acu_semestre = 0;
   
    console.log(lecturas);

    lecturas.forEach(lectura => {
        if(lectura.mes ===1){
            min = lecturas[0];
        } else{
            if(lectura.mes > 5 && lectura.mes <= 12){
                acu_semestre += lectura.valor;
            }

            //determinar lectura minima
            if(lectura.valor < min.valor){
                min = lectura;
            }
        }
        acu_anual += lectura.valor
    });

    //Resultados:
    let prom_anual = utils.promedio(acu_anual,12);
    console.log("Promedio anual: " + prom_anual);

    let prom_semestral = utils.promedio(acu_semestre, 6);
    console.log("Promedio semestre: " + prom_semestral);

})();