const juan = {
    nombre: 'Juan',
    apellido: 'Perez',
    email: 'juanperez@gmail.com',
    fechaNacimiento: new Date(1988,9,1),
    saludar: function(){
        console.log("Hola mi nombre es " + this.nombre);
    }
}

const persona2 = new Object();
persona2.nombre = 'Federico';
persona2.apellido = 'Gomez';
persona2.email = 'fedegomez@gmail.com';
persona2.fechaNacimiento = new Date(1988,9,1);
persona2.saludar = function(){
    console.log("Hola mi nombre es " + this.nombre);
}

console.log(persona2);
