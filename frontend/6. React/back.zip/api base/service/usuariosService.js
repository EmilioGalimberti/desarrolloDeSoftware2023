import fetch from "node-fetch"

const getUsuarios =  async (req, res) =>{
    const url = "https://jsonplaceholder.org/users"

    try{
        console.log("params", req.query)
        const {nombre} = req.query

        console.log("nombre", nombre)
        const promesa = await fetch(url)
        let data = await promesa.json()

        if(nombre){
            console.log("ingresamos")
            data = data.filter(item => {
                if(item.firstname == nombre){
                    return item
                }    
            })
        }
        res.status(200)
        res.send(data)
    }
    catch(error){
        console.log("error!!", error)
    }
}

// find(item=>{
//     return item.firstname == nombre
// })

const getUsuarioById =  async (req, res) =>{
    try{
        //obtengo de algun lado el articulo... (BD deberia ser)
        res.status(200)
        res.send(`Se solicito el articulo id: ${req.params.id}`)
    }
    catch(e){
        // manejaremos el error
    }
}

const insertUsuario =  async (req, res) =>{
    try{
      // agregar lógica de insert...
    }
    catch(e){
        // manejaremos el error
    }
}

export default{
    getUsuarios,
    getUsuarioById,
    insertUsuario
}