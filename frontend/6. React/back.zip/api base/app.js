import express from 'express'
import routerUsuarios from './routes/usuariosRuta.js'
import cors from 'cors';

const app = express()
app.use(cors())

const port = 3000

app.use(express.json())

app.use('/api', routerUsuarios.router)



app.listen(port, () => {
    console.log("Inicio de api...")
})