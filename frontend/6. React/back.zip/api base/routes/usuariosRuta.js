import express from 'express'
import servicio from '../service/usuariosService.js'


const router = express.Router()
router.get("/usuarios/:nombre", servicio.getUsuarios)
router.get("/usuarios", servicio.getUsuarios)
//router.get("/articulos/:id", servicio.getArticuloById)
//router.post("/articulos", servicio.insertArticulo)

export default{
    router
}