document.getElementById("parrafo1").style.color = "red";
document.getElementById("parrafo3").style.border = "solid";
document.getElementById("parrafo3").style.color = "blue";